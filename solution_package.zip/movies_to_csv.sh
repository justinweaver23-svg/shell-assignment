#!/bin/bash

# Justin Weaver
# Process movie data into basic CSV format

input="movies_raw.txt"

echo "Rank,Title,Year,Runtime,Rating,Votes,Actor"

cat "$input" | \
grep -v '^ *$' | \
while IFS= read line
do
    line=$(echo "$line" | sed 's/, */,/g')
    line=$(echo "$line" | sed 's/^ *//')

    if echo "$line" | grep -q '^[0-9]'; then
        echo "$line"
    fi
done
