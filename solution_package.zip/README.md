# Movie Data CSV Processor

This solution converts raw movie text into a simple CSV format.
The main script is movies_to_csv.sh.

## How to Run

1. Make the script executable  
   chmod u+x movies_to_csv.sh

2. Run the script  
   ./movies_to_csv.sh

The input file must be named movies_raw.txt.

## Build and Deploy

To build the deployment package  
make build

To deploy it to your git repo  
make deploy
